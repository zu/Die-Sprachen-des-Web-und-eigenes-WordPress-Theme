(function(html){html.className = html.className.replace(/\bno-js\b/,'js')})(document.documentElement);


Spry.Utils.addLoadListener(function() {

/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"http:\/\/wptheme.dev\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"recaptcha":{"messages":{"empty":"Bitte best\u00e4tigen Sie, dass Sie kein Roboter sind."}}};
/* ]]> */



/* <![CDATA[ */
var twentyseventeenScreenReaderText = {"quote":"<svg class=\"icon icon-quote-right\" aria-hidden=\"true\" role=\"img\"> <use href=\"#icon-quote-right\" xlink:href=\"#icon-quote-right\"><\/use> <\/svg>"};
/* ]]> */


});
